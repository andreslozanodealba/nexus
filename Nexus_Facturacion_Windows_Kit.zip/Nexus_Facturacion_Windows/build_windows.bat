@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ============================================
echo  Nexus Facturacion - Compilacion para Windows
echo ============================================

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python no esta instalado. Descargue Python 3.10 o superior desde python.org
  echo         y marque la casilla "Add Python to PATH" al instalar.
  pause & exit /b 1
)

echo.
echo [1/3] Instalando dependencias...
python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 ( echo [ERROR] Fallo la instalacion de dependencias & pause & exit /b 1 )

echo.
echo [2/3] Generando el programa (.exe)...
pyinstaller --noconfirm --clean --windowed --name NexusFacturacion ^
  --icon nexus.ico --add-data "nexus-icon.png;." nexus.py
if errorlevel 1 ( echo [ERROR] Fallo PyInstaller & pause & exit /b 1 )

echo.
echo [3/3] Creando el instalador (Inno Setup)...
set ISCC=
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if "%ISCC%"=="" (
  echo [AVISO] Inno Setup 6 no esta instalado. Descarguelo de jrsoftware.org/isinfo.php
  echo         e instalelo, luego ejecute de nuevo este archivo.
  echo         El programa ya quedo en dist\NexusFacturacion\NexusFacturacion.exe
  pause & exit /b 1
)
"%ISCC%" installer.iss
if errorlevel 1 ( echo [ERROR] Fallo Inno Setup & pause & exit /b 1 )

echo.
echo LISTO. El instalador esta en: installer_output\NexusFacturacion_Setup_1.0.0.exe
pause
