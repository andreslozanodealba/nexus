# nexusfinal_empaquetable.py
import datetime
import json
import os
import sys
from PyQt6.QtCore import Qt, QPoint
from PyQt6.QtGui import QFont, QTextDocument, QIcon
from PyQt6.QtPrintSupport import QPrinter
from PyQt6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QComboBox,
    QDialogButtonBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

if sys.platform.startswith("win"):
  # Windows: los datos van en AppData del usuario (Program Files no es escribible)
  USER_DATA_DIR = os.path.join(
    os.environ.get("APPDATA", os.path.expanduser("~")), "NexusFacturacion", "data"
  )
else:
  USER_DATA_DIR = "/opt/nexus-facturacion/data"

APP_NAME = "Nexus Facturación"
APP_DESKTOP_ID = "nexus-facturacion"
APP_ICON_SYSTEM = "/usr/share/icons/hicolor/256x256/apps/nexus-facturacion.png"
_BASE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
APP_ICON_LOCAL = os.path.join(_BASE_DIR, "nexus-icon.png")
APP_ICON_PATH = APP_ICON_SYSTEM if os.path.exists(APP_ICON_SYSTEM) else APP_ICON_LOCAL

os.makedirs(USER_DATA_DIR, exist_ok=True)

DB_USERS_CONFIG = os.path.join(USER_DATA_DIR, "bdd_usuarios_sistema.json")
DB_PRODUCTOS = os.path.join(USER_DATA_DIR, "bdd_productos_global.json")
ADMIN_MASTER_USER = "admin"
ADMIN_MASTER_PASS = "0218"

STYLESHEET_CYBER_MEDICO = """
    QMainWindow, QDialog {
        background-color: #0b0c16;
    }
    QWidget {
        font-family: 'Segoe UI', Arial, sans-serif;
        color: #e0f2fe;
    }
    QFrame#sidebar {
        background-color: #1e3a8a;
        border-right: 1px solid #1f2041;
    }
    QLabel {
        color: #e0f2fe;
        font-size: 13px;
    }
    QLineEdit, QComboBox, QTextEdit {
        background-color: #07080f;
        color: #e0f2fe;
        border: 1px solid #1f2041;
        border-radius: 2px;
        padding: 4px 6px;
        font-size: 12px;
    }
    QLineEdit:focus, QComboBox:focus, QTextEdit:focus {
        border: 1px solid #00f0ff;
    }
    QPushButton {
        background-color: #1e3a8a;
        color: #e0f2fe;
        border: 1px solid #3b82f6;
        border-radius: 2px;
        padding: 4px 8px;
        font-weight: 600;
        font-size: 11px;
    }
    QPushButton:hover {
        background-color: #1d4ed8;
        border: 1px solid #00f0ff;
        color: #00f0ff;
    }
    QPushButton#navBtn:checked {
        background-color: #0f1c4d;
    }
    QTableWidget {
        background-color: #07080f;
        color: #e0f2fe;
        gridline-color: #1f2041;
        border: 1px solid #1f2041;
        selection-background-color: #1a1b35;
        selection-color: #00f0ff;
    }
    QHeaderView::section {
        background-color: #0f1021;
        color: #e0f2fe;
        font-weight: bold;
        padding: 4px;
        border: 1px solid #1f2041;
    }
"""


def cargar_usuarios_sistema():
  if os.path.exists(DB_USERS_CONFIG):
    try:
      with open(DB_USERS_CONFIG, "r", encoding="utf-8") as f:
        return json.load(f)
    except:
      pass
  data = {
      "usuarios": [
          {"usuario": "admin", "password": ADMIN_MASTER_PASS, "rol": "admin"},
          {"usuario": "admin2", "password": ADMIN_MASTER_PASS, "rol": "admin"},
          {"usuario": "admin3", "password": ADMIN_MASTER_PASS, "rol": "admin"},
          {"usuario": "empleado1", "password": "123", "rol": "empleado"},
          {"usuario": "empleado2", "password": "123", "rol": "empleado"},
      ]
  }
  guardar_usuarios_sistema(data)
  return data


def guardar_usuarios_sistema(data):
  with open(DB_USERS_CONFIG, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=4, ensure_ascii=False)


def cargar_productos_global():
  if os.path.exists(DB_PRODUCTOS):
    try:
      with open(DB_PRODUCTOS, "r", encoding="utf-8") as f:
        return json.load(f)
    except:
      pass
  data = {"inventario": []}
  guardar_productos_global(data)
  return data


def guardar_productos_global(data):
  with open(DB_PRODUCTOS, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=4, ensure_ascii=False)


def cargar_db_usuario(username):
  archivo = os.path.join(USER_DATA_DIR, f"bdd_user_{username}.json")
  if os.path.exists(archivo):
    try:
      with open(archivo, "r", encoding="utf-8") as f:
        return json.load(f)
    except:
      pass
  data = {"clientes": [], "facturas": []}
  guardar_db_usuario(username, data)
  return data


def guardar_db_usuario(username, data):
  archivo = os.path.join(USER_DATA_DIR, f"bdd_user_{username}.json")
  with open(archivo, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=4, ensure_ascii=False)


class InitialRoleDialog(QDialog):

  def __init__(self):
    super().__init__()
    self.setWindowTitle("NEXUS // Selección de Rol")
    self.setFixedSize(380, 220)
    self.setStyleSheet(STYLESHEET_CYBER_MEDICO)
    self.role_selected = None

    layout = QVBoxLayout(self)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(10)

    title = QLabel("SELECCIONE SU ROL")
    title.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
    title.setAlignment(Qt.AlignmentFlag.AlignCenter)
    layout.addWidget(title)

    btn_admin = QPushButton("Administrador (Control Total)")
    btn_admin.setFixedHeight(40)
    btn_admin.clicked.connect(lambda: self.seleccionar("admin"))
    layout.addWidget(btn_admin)

    btn_user = QPushButton("Usuario / Empleado")
    btn_user.setFixedHeight(40)
    btn_user.clicked.connect(lambda: self.seleccionar("empleado"))
    layout.addWidget(btn_user)

  def seleccionar(self, rol):
    self.role_selected = rol
    self.accept()


class LoginDialog(QDialog):

  def __init__(self, role):
    super().__init__()
    self.role = role
    self.setWindowTitle(
        f"Autenticación - {'Administrador' if role=='admin' else 'Empleado'}"
    )
    self.setFixedSize(340, 260)
    self.setStyleSheet(STYLESHEET_CYBER_MEDICO)
    self.authenticated = False
    self.current_user_name = ""
    self.current_user_role = role

    layout = QVBoxLayout(self)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(8)

    title = QLabel(
        f"ACCESO DE {'ADMIN' if role=='admin' else 'EMPLEADO'}"
    )
    title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    title.setAlignment(Qt.AlignmentFlag.AlignCenter)
    layout.addWidget(title)

    layout.addWidget(QLabel("Usuario:"))
    self.input_user = QLineEdit()
    layout.addWidget(self.input_user)

    layout.addWidget(QLabel("Contraseña:"))
    self.input_pass = QLineEdit()
    self.input_pass.setEchoMode(QLineEdit.EchoMode.Password)
    layout.addWidget(self.input_pass)

    layout.addSpacing(5)
    btn_login = QPushButton("Conectar")
    btn_login.setFixedHeight(32)
    btn_login.clicked.connect(self.verificar)
    layout.addWidget(btn_login)

    if role == "empleado":
      btn_reg = QPushButton("Registrarse como Empleado")
      btn_reg.setFixedHeight(30)
      btn_reg.clicked.connect(self.registrar_nuevo_empleado)
      layout.addWidget(btn_reg)

  def verificar(self):
    u = self.input_user.text().strip()
    p = self.input_pass.text().strip()
    sys_data = cargar_usuarios_sistema()

    match = False
    user_role_found = ""
    for usr in sys_data.get("usuarios", []):
      if usr["usuario"] == u and usr["password"] == p:
        match = True
        user_role_found = usr.get("rol", "empleado")
        break

    if match:
      if self.role == "admin" and user_role_found != "admin":
        QMessageBox.warning(
            self, "Error", "Este usuario no tiene permisos de Administrador."
        )
        return
      self.authenticated = True
      self.current_user_name = u
      self.current_user_role = user_role_found
      self.accept()
    else:
      QMessageBox.warning(self, "Error", "Credenciales incorrectas.")

  def registrar_nuevo_empleado(self):
    u = self.input_user.text().strip()
    p = self.input_pass.text().strip()
    if not u or not p:
      QMessageBox.warning(
          self, "Aviso", "Ingrese usuario y contraseña para registrarse."
      )
      return
    sys_data = cargar_usuarios_sistema()
    for usr in sys_data.get("usuarios", []):
      if usr["usuario"] == u:
        QMessageBox.warning(self, "Error", "El usuario ya existe.")
        return
    sys_data["usuarios"].append({"usuario": u, "password": p, "rol": "empleado"})
    guardar_usuarios_sistema(sys_data)
    cargar_db_usuario(u)
    QMessageBox.information(
        self, "Éxito", f"Empleado '{u}' registrado correctamente."
    )


class CambiarPasswordDialog(QDialog):

  def __init__(self, username, parent=None):
    super().__init__(parent)
    self.username = username
    self.setWindowTitle("Cambiar Contraseña")
    self.setFixedSize(340, 200)
    self.setStyleSheet(STYLESHEET_CYBER_MEDICO)

    layout = QVBoxLayout(self)
    layout.setContentsMargins(20, 20, 20, 20)

    title = QLabel(f"CAMBIAR CONTRASEÑA: {username}")
    title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    layout.addWidget(title)

    form = QFormLayout()
    self.inp_nueva = QLineEdit()
    self.inp_nueva.setEchoMode(QLineEdit.EchoMode.Password)
    form.addRow(QLabel("Nueva Contraseña:"), self.inp_nueva)
    layout.addLayout(form)

    btn_guardar = QPushButton("Actualizar Contraseña")
    btn_guardar.clicked.connect(self.guardar)
    layout.addWidget(btn_guardar)

  def guardar(self):
    nueva = self.inp_nueva.text().strip()
    if not nueva:
      QMessageBox.warning(self, "Aviso", "La contraseña no puede estar vacía.")
      return
    sys_data = cargar_usuarios_sistema()
    for usr in sys_data.get("usuarios", []):
      if usr["usuario"] == self.username:
        usr["password"] = nueva
        break
    guardar_usuarios_sistema(sys_data)
    QMessageBox.information(self, "Éxito", "Contraseña actualizada con éxito.")
    self.accept()


class VerBDDexternaDialog(QDialog):

  def __init__(self, parent=None):
    super().__init__(parent)
    self.setWindowTitle("Visor de Registros del Sistema")
    self.setFixedSize(650, 450)
    self.setStyleSheet(STYLESHEET_CYBER_MEDICO)

    layout = QVBoxLayout(self)
    layout.setContentsMargins(10, 10, 10, 10)
    layout.setSpacing(8)

    title = QLabel("SELECCIONE USUARIO A INSPECCIONAR")
    title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    layout.addWidget(title)

    top_row = QHBoxLayout()
    self.combo_users = QComboBox()
    sys_data = cargar_usuarios_sistema()
    for u in sys_data.get("usuarios", []):
      self.combo_users.addItem(u["usuario"])
    top_row.addWidget(self.combo_users)

    btn_cargar = QPushButton("Cargar Datos")
    btn_cargar.clicked.connect(self.cargar_datos)
    top_row.addWidget(btn_cargar)
    layout.addLayout(top_row)

    self.tabla_ver = TablaArrastre()
    self.tabla_ver.setColumnCount(5)
    self.tabla_ver.setHorizontalHeaderLabels(
        ["ID", "Tipo", "Detalle 1", "Detalle 2", "Detalle 3"]
    )
    header = self.tabla_ver.horizontalHeader()
    header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    layout.addWidget(self.tabla_ver)

  def cargar_datos(self):
    usr = self.combo_users.currentText()
    db = cargar_db_usuario(usr)
    self.tabla_ver.setRowCount(0)
    row = 0
    for c in db.get("clientes", []):
      self.tabla_ver.insertRow(row)
      self.tabla_ver.setItem(row, 0, QTableWidgetItem(str(c.get("id", ""))))
      self.tabla_ver.setItem(row, 1, QTableWidgetItem("Cliente"))
      self.tabla_ver.setItem(row, 2, QTableWidgetItem(c.get("nombre", "")))
      self.tabla_ver.setItem(row, 3, QTableWidgetItem(c.get("telefono", "")))
      self.tabla_ver.setItem(row, 4, QTableWidgetItem(c.get("email", "")))
      row += 1
    for f in db.get("facturas", []):
      self.tabla_ver.insertRow(row)
      self.tabla_ver.setItem(row, 0, QTableWidgetItem(str(f.get("id", ""))))
      self.tabla_ver.setItem(row, 1, QTableWidgetItem("Factura"))
      self.tabla_ver.setItem(row, 2, QTableWidgetItem(f.get("cliente", "")))
      self.tabla_ver.setItem(row, 3, QTableWidgetItem(f.get("fecha", "")))
      self.tabla_ver.setItem(row, 4, QTableWidgetItem(f.get("total", "")))
      row += 1


class VerFacturaTxtDialog(QDialog):

  def __init__(self, fac_id, username="", parent=None):
    super().__init__(parent)
    self.fac_id = fac_id
    self.username = username
    self.factura = None
    self.setWindowTitle(f"Factura Comercial: {fac_id}")
    self.setMinimumSize(860, 650)
    self.resize(980, 720)

    self.setStyleSheet(STYLESHEET_CYBER_MEDICO + """
      QFrame#invoice_page {
        background-color: #0f1021;
        border: 1px solid #3b82f6;
        border-radius: 3px;
      }
      QFrame#invoice_header {
        background-color: #07080f;
        border-bottom: 1px solid #3b82f6;
      }
      QFrame#invoice_info, QFrame#invoice_totals {
        background-color: #07080f;
        border: 1px solid #1f2041;
      }
      QLabel#invoice_brand {
        color: #60a5fa;
        font-size: 22px;
        font-weight: 700;
        letter-spacing: 1px;
      }
      QLabel#invoice_subtitle {
        color: #94a3b8;
        font-size: 10px;
      }
      QLabel#invoice_title {
        color: #e0f2fe;
        font-size: 20px;
        font-weight: 700;
      }
      QLabel#invoice_number {
        color: #60a5fa;
        font-size: 13px;
        font-weight: 700;
        border: 1px solid #3b82f6;
        padding: 7px 12px;
      }
      QLabel#section_title {
        color: #e0f2fe;
        font-size: 13px;
        font-weight: 700;
      }
      QLabel#invoice_value {
        color: #e0f2fe;
        font-size: 12px;
      }
      QTableWidget#invoice_table {
        background-color: #07080f;
        color: #e0f2fe;
        border: 1px solid #3b82f6;
        gridline-color: #1f2041;
        selection-background-color: #07080f;
        selection-color: #e0f2fe;
      }
      QTableWidget#invoice_table::item {
        padding: 7px;
      }
      QHeaderView::section {
        background-color: #1e3a8a;
        color: #e0f2fe;
        border: 1px solid #3b82f6;
        padding: 7px;
        font-weight: 700;
      }
      QLabel#invoice_total_label {
        color: #e0f2fe;
        font-size: 14px;
        font-weight: 700;
      }
      QLabel#invoice_total {
        color: #60a5fa;
        font-size: 18px;
        font-weight: 700;
      }
      QLabel#invoice_thanks {
        color: #94a3b8;
        font-size: 11px;
      }
    """)

    root = QVBoxLayout(self)
    root.setContentsMargins(14, 14, 14, 14)
    root.setSpacing(10)

    page = QFrame()
    page.setObjectName("invoice_page")
    page_lay = QVBoxLayout(page)
    page_lay.setContentsMargins(18, 18, 18, 18)
    page_lay.setSpacing(12)

    header = QFrame()
    header.setObjectName("invoice_header")
    header_lay = QHBoxLayout(header)
    header_lay.setContentsMargins(12, 12, 12, 12)

    brand_box = QVBoxLayout()
    brand = QLabel("NEXUS")
    brand.setObjectName("invoice_brand")
    brand_box.addWidget(brand)
    subtitle = QLabel("SISTEMA DE GESTIÓN ADMINISTRATIVA")
    subtitle.setObjectName("invoice_subtitle")
    brand_box.addWidget(subtitle)
    header_lay.addLayout(brand_box)
    header_lay.addStretch()

    right = QVBoxLayout()
    title = QLabel("FACTURA")
    title.setObjectName("invoice_title")
    title.setAlignment(Qt.AlignmentFlag.AlignRight)
    right.addWidget(title)
    self.lbl_numero = QLabel(f"N° {fac_id}")
    self.lbl_numero.setObjectName("invoice_number")
    self.lbl_numero.setAlignment(Qt.AlignmentFlag.AlignCenter)
    right.addWidget(self.lbl_numero)
    header_lay.addLayout(right)
    page_lay.addWidget(header)

    self.info = QFrame()
    self.info.setObjectName("invoice_info")
    info_lay = QHBoxLayout(self.info)
    info_lay.setContentsMargins(12, 10, 12, 10)

    self.lbl_emisor = QLabel()
    self.lbl_emisor.setObjectName("invoice_value")
    self.lbl_fecha = QLabel()
    self.lbl_fecha.setObjectName("invoice_value")
    self.lbl_cliente = QLabel()
    self.lbl_cliente.setObjectName("invoice_value")

    left_info = QVBoxLayout()
    left_info.addWidget(QLabel("DATOS DE EMISIÓN", objectName="section_title"))
    left_info.addWidget(self.lbl_emisor)
    left_info.addWidget(self.lbl_fecha)
    info_lay.addLayout(left_info)
    info_lay.addStretch()

    client_info = QVBoxLayout()
    client_info.addWidget(QLabel("CLIENTE", objectName="section_title"))
    client_info.addWidget(self.lbl_cliente)
    info_lay.addLayout(client_info)
    page_lay.addWidget(self.info)

    lbl_productos = QLabel("DESCRIPCIÓN DE PRODUCTOS")
    lbl_productos.setObjectName("section_title")
    page_lay.addWidget(lbl_productos)

    self.tabla_factura = QTableWidget()
    self.tabla_factura.setObjectName("invoice_table")
    self.tabla_factura.setColumnCount(4)
    self.tabla_factura.setHorizontalHeaderLabels(
        ["Producto", "Cantidad", "Precio Unitario ($)", "Total ($)"]
    )
    self.tabla_factura.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    self.tabla_factura.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
    self.tabla_factura.setWordWrap(True)
    self.tabla_factura.verticalHeader().setVisible(False)
    self.tabla_factura.verticalHeader().setSectionResizeMode(
        QHeaderView.ResizeMode.ResizeToContents
    )
    self.tabla_factura.horizontalHeader().setSectionResizeMode(
        0, QHeaderView.ResizeMode.Stretch
    )
    for col in (1, 2, 3):
      self.tabla_factura.horizontalHeader().setSectionResizeMode(
          col, QHeaderView.ResizeMode.ResizeToContents
      )
    page_lay.addWidget(self.tabla_factura, 1)

    totals = QFrame()
    totals.setObjectName("invoice_totals")
    totals_lay = QVBoxLayout(totals)
    totals_lay.setContentsMargins(12, 10, 12, 10)
    total_row = QHBoxLayout()
    total_label = QLabel("TOTAL A PAGAR")
    total_label.setObjectName("invoice_total_label")
    self.lbl_total = QLabel("$0.00")
    self.lbl_total.setObjectName("invoice_total")
    self.lbl_total.setAlignment(Qt.AlignmentFlag.AlignRight)
    total_row.addWidget(total_label)
    total_row.addStretch()
    total_row.addWidget(self.lbl_total)
    totals_lay.addLayout(total_row)
    page_lay.addWidget(totals)

    thanks = QLabel("Comprobante generado por Nexus.")
    thanks.setObjectName("invoice_thanks")
    thanks.setAlignment(Qt.AlignmentFlag.AlignCenter)
    page_lay.addWidget(thanks)

    root.addWidget(page, 1)

    btn_layout = QHBoxLayout()
    btn_layout.addStretch()
    btn_exportar = QPushButton("Exportar / Guardar TXT")
    btn_exportar.clicked.connect(self.exportar_factura)
    btn_layout.addWidget(btn_exportar)
    btn_exportar_pdf = QPushButton("Exportar a PDF")
    btn_exportar_pdf.clicked.connect(self.exportar_pdf)
    btn_layout.addWidget(btn_exportar_pdf)
    btn_cerrar = QPushButton("Cerrar")
    btn_cerrar.clicked.connect(self.accept)
    btn_layout.addWidget(btn_cerrar)
    root.addLayout(btn_layout)

    self.cargar_formato_factura()

  def cargar_formato_factura(self):
    cliente = "Cliente General"
    fecha = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total = "0.00"
    items = []

    if self.username:
      db = cargar_db_usuario(self.username)
      for f in db.get("facturas", []):
        if str(f.get("id")) == str(self.fac_id):
          self.factura = f
          cliente = f.get("cliente", cliente)
          fecha = f.get("fecha", fecha)
          total = str(f.get("total", total)).replace("$", "")
          items = f.get("items", [])
          break

    self.lbl_emisor.setText(
        f"Emitida por: {self.username.upper() if self.username else 'SISTEMA'}"
    )
    self.lbl_fecha.setText(f"Fecha/Hora: {fecha}")
    self.lbl_cliente.setText(f"{cliente}")

    self.tabla_factura.setRowCount(0)
    for item in items:
      row = self.tabla_factura.rowCount()
      self.tabla_factura.insertRow(row)
      nombre = str(item.get("nombre", "Producto"))
      cantidad = item.get("cantidad", 1)
      try:
        precio = float(item.get("precio", 0))
      except (TypeError, ValueError):
        precio = 0.0
      subtotal = float(item.get("subtotal", cantidad * precio))
      self.tabla_factura.setItem(row, 0, QTableWidgetItem(nombre))
      self.tabla_factura.setItem(row, 1, QTableWidgetItem(str(cantidad)))
      self.tabla_factura.setItem(row, 2, QTableWidgetItem(f"${precio:,.2f}"))
      self.tabla_factura.setItem(row, 3, QTableWidgetItem(f"${subtotal:,.2f}"))

    if not items:
      row = self.tabla_factura.rowCount()
      self.tabla_factura.insertRow(row)
      self.tabla_factura.setItem(row, 0, QTableWidgetItem("Consulta / Servicio General"))
      self.tabla_factura.setItem(row, 1, QTableWidgetItem("1"))
      self.tabla_factura.setItem(row, 2, QTableWidgetItem(f"${float(total or 0):,.2f}"))
      self.tabla_factura.setItem(row, 3, QTableWidgetItem(f"${float(total or 0):,.2f}"))

    try:
      total_num = float(str(total).replace(",", ""))
      self.lbl_total.setText(f"${total_num:,.2f}")
    except (TypeError, ValueError):
      self.lbl_total.setText(f"${total}")

  def exportar_factura(self):
    archivo_guardar, _ = QFileDialog.getSaveFileName(
        self,
        "Exportar Factura",
        f"Factura_{self.fac_id}.txt",
        "Archivos de Texto (*.txt);;Todos los archivos (*.*)",
    )
    if archivo_guardar:
      try:
        lines = [
            "=" * 58,
            "NEXUS - COMPROBANTE DE FACTURA",
            "=" * 58,
            f"N° de Factura : {self.fac_id}",
            f"Emitida por   : {self.username.upper() if self.username else 'SISTEMA'}",
            f"Fecha/Hora    : {self.lbl_fecha.text().split(': ', 1)[-1]}",
            f"Cliente       : {self.lbl_cliente.text()}",
            "-" * 58,
            "DESCRIPCIÓN                         CANT  VALOR",
            "-" * 58,
        ]
        for r in range(self.tabla_factura.rowCount()):
          vals = [self.tabla_factura.item(r, c).text() if self.tabla_factura.item(r, c) else "" for c in range(4)]
          lines.append(f"{vals[0]:<35} {vals[1]:<5} {vals[3]}")
        lines.extend([
            "-" * 58,
            f"TOTAL A PAGAR                    {self.lbl_total.text()}",
            "=" * 58,
            "Comprobante generado por Nexus.",
            "=" * 58,
        ])
        with open(archivo_guardar, "w", encoding="utf-8") as f_out:
          f_out.write("\n".join(lines))
        QMessageBox.information(
            self, "Éxito", f"Factura exportada correctamente en:\n{archivo_guardar}"
        )
      except Exception as e:
        QMessageBox.warning(self, "Error", f"No se pudo guardar el archivo: {e}")

  def exportar_pdf(self):
    archivo_guardar, _ = QFileDialog.getSaveFileName(
        self,
        "Exportar Factura a PDF",
        f"Factura_{self.fac_id}.pdf",
        "Archivos PDF (*.pdf);;Todos los archivos (*.*)",
    )
    if archivo_guardar:
      try:
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        printer.setOutputFileName(archivo_guardar)

        rows_html = ""
        for r in range(self.tabla_factura.rowCount()):
          vals = [self.tabla_factura.item(r, c).text() if self.tabla_factura.item(r, c) else "" for c in range(4)]
          safe = [v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") for v in vals]
          rows_html += (
              f"<tr>"
              f"<td style='text-align:left;'>{safe[0]}</td>"
              f"<td style='text-align:center;'>{safe[1]}</td>"
              f"<td style='text-align:right;'>{safe[2]}</td>"
              f"<td style='text-align:right;'>{safe[3]}</td>"
              f"</tr>"
          )

        html_content = f"""
        <html><head><style>
          body {{ background:#ffffff; color:#111111; font-family:Helvetica, Arial, sans-serif; margin:0; padding:15px; }}
          .invoice-box {{ max-width: 700px; margin: auto; padding: 20px; border: 1px solid #d1d5db; background: #ffffff; }}
          .header-table, .details-table, .items-table {{ width: 100%; border-collapse: collapse; }}
          .header-table td {{ vertical-align: top; padding: 0; }}
          .brand {{ color: #1e3a8a; font-size: 24px; font-weight: bold; }}
          .sub {{ color: #6b7280; font-size: 11px; margin-top: 2px; }}
          .title-section {{ text-align: right; }}
          .title {{ color: #111827; font-size: 22px; font-weight: bold; }}
          .num {{ color: #1e3a8a; font-size: 13px; font-weight: bold; margin-top: 4px; }}
          .info-box {{ margin-top: 20px; margin-bottom: 20px; padding: 12px; background: #f9fafb; border: 1px solid #e5e7eb; font-size: 12px; line-height: 1.5; }}
          .items-table th {{ background: #1e3a8a; color: #ffffff; padding: 8px 10px; font-size: 12px; border: 1px solid #1e3a8a; }}
          .items-table td {{ padding: 8px 10px; font-size: 12px; border: 1px solid #e5e7eb; color: #374151; }}
          .total-box {{ margin-top: 15px; width: 100%; border-collapse: collapse; }}
          .total-box td {{ padding: 10px; font-size: 14px; font-weight: bold; background: #f3f4f6; border: 1px solid #d1d5db; text-align: right; }}
          .thanks {{ text-align: center; color: #9ca3af; font-size: 11px; margin-top: 25px; }}
        </style></head><body>
          <div class="invoice-box">
            <table class="header-table">
              <tr>
                <td>
                  <div class="brand">NEXUS</div>
                  <div class="sub">SISTEMA DE GESTIÓN ADMINISTRATIVA</div>
                </td>
                <td class="title-section">
                  <div class="title">FACTURA</div>
                  <div class="num">N° {self.fac_id}</div>
                </td>
              </tr>
            </table>
            
            <div class="info-box">
              <strong>DATOS DE EMISIÓN:</strong><br>
              Emitida por: {self.username.upper() if self.username else 'SISTEMA'}<br>
              {self.lbl_fecha.text()}<br><br>
              <strong>CLIENTE:</strong> {self.lbl_cliente.text()}
            </div>

            <table class="items-table">
              <thead>
                <tr>
                  <th style="text-align:left;">Producto</th>
                  <th style="text-align:center; width: 70px;">Cant</th>
                  <th style="text-align:right; width: 110px;">Precio Unit.</th>
                  <th style="text-align:right; width: 110px;">Total</th>
                </tr>
              </thead>
              <tbody>
                {rows_html}
              </tbody>
            </table>

            <table class="total-box">
              <tr>
                <td>TOTAL A PAGAR: {self.lbl_total.text()}</td>
              </tr>
            </table>

            <div class="thanks">Comprobante generado por Nexus.</div>
          </div>
        </body></html>
        """
        document = QTextDocument()
        document.setHtml(html_content)
        page_rect = printer.pageRect(QPrinter.Unit.Point)
        document.setPageSize(page_rect.size())
        document.print(printer)
        QMessageBox.information(
            self, "Éxito", f"Factura exportada a PDF correctamente en:\n{archivo_guardar}"
        )
      except Exception as e:
        QMessageBox.warning(self, "Error", f"No se pudo exportar el PDF: {e}")


class RegistrarClienteModal(QDialog):

  def __init__(self, username, cliente_data=None, parent=None):
    super().__init__(parent)
    self.username = username
    self.cliente_data = cliente_data
    self.setWindowTitle(
        "Modificar Cliente" if cliente_data else "Registrar Cliente"
    )
    self.setFixedSize(360, 320)
    self.setStyleSheet(STYLESHEET_CYBER_MEDICO)

    layout = QVBoxLayout(self)
    layout.setContentsMargins(15, 15, 15, 15)

    title = QLabel(
        "EDITAR CLIENTE" if cliente_data else "NUEVO CLIENTE"
    )
    title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    layout.addWidget(title)

    form = QFormLayout()
    self.inp_nombre = QLineEdit()
    self.inp_email = QLineEdit()
    self.inp_tel = QLineEdit()
    self.inp_dir = QLineEdit()

    if cliente_data:
      self.inp_nombre.setText(cliente_data.get("nombre", ""))
      self.inp_email.setText(cliente_data.get("email", ""))
      self.inp_tel.setText(cliente_data.get("telefono", ""))
      self.inp_dir.setText(cliente_data.get("direccion", ""))

    form.addRow(QLabel("Nombre:"), self.inp_nombre)
    form.addRow(QLabel("Email:"), self.inp_email)
    form.addRow(QLabel("Teléfono:"), self.inp_tel)
    form.addRow(QLabel("Dirección:"), self.inp_dir)
    layout.addLayout(form)

    btn_guardar = QPushButton("Guardar Cambios" if cliente_data else "Guardar")
    btn_guardar.clicked.connect(self.guardar)
    layout.addWidget(btn_guardar)

  def guardar(self):
    nombre = self.inp_nombre.text().strip()
    if not nombre:
      QMessageBox.warning(self, "Aviso", "El nombre es obligatorio.")
      return
    db = cargar_db_usuario(self.username)
    if self.cliente_data:
      for c in db.get("clientes", []):
        if c.get("id") == self.cliente_data.get("id"):
          c["nombre"] = nombre
          c["email"] = self.inp_email.text().strip()
          c["telefono"] = self.inp_tel.text().strip()
          c["direccion"] = self.inp_dir.text().strip()
          break
    else:
      new_id = (
          str(
              max(
                  [int(c.get("id", 0)) for c in db.get("clientes", [])]
                  + [0]
              )
              + 1
          )
          if db.get("clientes")
          else "1"
      )
      nuevo = {
          "id": new_id,
          "nombre": nombre,
          "email": self.inp_email.text().strip(),
          "telefono": self.inp_tel.text().strip(),
          "direccion": self.inp_dir.text().strip(),
          "estado": "Activo",
          "fecha": datetime.datetime.now().strftime("%Y-%m-%d"),
      }
      db["clientes"].append(nuevo)
    guardar_db_usuario(self.username, db)
    QMessageBox.information(
        self, "Éxito", "Operación realizada correctamente."
    )
    self.accept()


class RegistrarProductoModal(QDialog):

  def __init__(self, prod_data=None, parent=None):
    super().__init__(parent)
    self.prod_data = prod_data
    self.setWindowTitle(
        "Modificar Producto" if prod_data else "Registrar Producto"
    )
    self.setFixedSize(360, 320)
    self.setStyleSheet(STYLESHEET_CYBER_MEDICO)

    layout = QVBoxLayout(self)
    layout.setContentsMargins(15, 15, 15, 15)

    title = QLabel(
        "EDITAR PRODUCTO (GLOBAL)"
        if prod_data
        else "NUEVO PRODUCTO (GLOBAL)"
    )
    title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    layout.addWidget(title)

    form = QFormLayout()
    self.inp_nombre = QLineEdit()
    self.inp_codigo = QLineEdit()
    self.inp_desc = QLineEdit()
    self.inp_precio = QLineEdit()
    self.inp_cat = QLineEdit()

    if prod_data:
      self.inp_nombre.setText(prod_data.get("nombre", ""))
      self.inp_codigo.setText(prod_data.get("codigo", ""))
      self.inp_desc.setText(prod_data.get("descripcion", ""))
      self.inp_precio.setText(prod_data.get("precio", ""))
      self.inp_cat.setText(prod_data.get("categoria", ""))

    form.addRow(QLabel("Nombre:"), self.inp_nombre)
    form.addRow(QLabel("Código:"), self.inp_codigo)
    form.addRow(QLabel("Descripción:"), self.inp_desc)
    form.addRow(QLabel("Precio ($):"), self.inp_precio)
    form.addRow(QLabel("Categoría:"), self.inp_cat)
    layout.addLayout(form)

    btn_guardar = QPushButton("Guardar Cambios" if prod_data else "Guardar")
    btn_guardar.clicked.connect(self.guardar)
    layout.addWidget(btn_guardar)

  def guardar(self):
    nombre = self.inp_nombre.text().strip()
    precio = self.inp_precio.text().strip()
    if not nombre or not precio:
      QMessageBox.warning(self, "Aviso", "Nombre y precio son obligatorios.")
      return
    db = cargar_productos_global()
    if self.prod_data:
      for p in db.get("inventario", []):
        if p.get("id") == self.prod_data.get("id"):
          p["nombre"] = nombre
          p["codigo"] = self.inp_codigo.text().strip()
          p["descripcion"] = self.inp_desc.text().strip()
          p["precio"] = precio
          p["categoria"] = self.inp_cat.text().strip()
          break
    else:
      new_id = (
          str(
              max(
                  [int(p.get("id", 0)) for p in db.get("inventario", [])]
                  + [0]
              )
              + 1
          )
          if db.get("inventario")
          else "1"
      )
      nuevo = {
          "id": new_id,
          "nombre": nombre,
          "codigo": self.inp_codigo.text().strip(),
          "descripcion": self.inp_desc.text().strip(),
          "precio": precio,
          "categoria": self.inp_cat.text().strip(),
          "estado": "activo",
      }
      db["inventario"].append(nuevo)
    guardar_productos_global(db)
    QMessageBox.information(
        self, "Éxito", "Inventario global actualizado correctamente."
    )
    self.accept()


class GenerarFacturaModal(QDialog):

  def __init__(self, username, parent=None):
    super().__init__(parent)
    self.username = username
    self.setWindowTitle("Generar Factura XML")
    self.setFixedSize(500, 450)
    self.setStyleSheet(STYLESHEET_CYBER_MEDICO)

    layout = QVBoxLayout(self)
    layout.setContentsMargins(15, 15, 15, 15)

    title = QLabel("NUEVA FACTURA (XML)")
    title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    layout.addWidget(title)

    form = QFormLayout()
    self.inp_id = QLineEdit(
        f"FAC-{datetime.datetime.now().strftime('%H%M%S')}"
    )
    
    self.combo_cliente = QComboBox()
    db_usr = cargar_db_usuario(username)
    for c in db_usr.get("clientes", []):
      self.combo_cliente.addItem(c.get("nombre", ""))

    self.combo_producto = QComboBox()
    self.prod_map = []
    db_prod = cargar_productos_global()
    for p in db_prod.get("inventario", []):
      p_nom = p.get("nombre", "")
      p_prec = p.get("precio", "0")
      self.combo_producto.addItem(f"{p_nom} - ${p_prec}")
      self.prod_map.append(p)

    self.inp_cantidad = QLineEdit("1")

    form.addRow(QLabel("ID Factura:"), self.inp_id)
    form.addRow(QLabel("Cliente:"), self.combo_cliente)
    form.addRow(QLabel("Producto:"), self.combo_producto)
    form.addRow(QLabel("Cantidad:"), self.inp_cantidad)
    layout.addLayout(form)

    btn_add_prod = QPushButton("Agregar Producto a la Factura")
    btn_add_prod.clicked.connect(self.agregar_item_factura)
    layout.addWidget(btn_add_prod)

    self.tabla_items = QTableWidget()
    self.tabla_items.setColumnCount(4)
    self.tabla_items.setHorizontalHeaderLabels(["Producto", "Cantidad", "Precio Unit.", "Subtotal"])
    self.tabla_items.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    layout.addWidget(self.tabla_items)

    self.items_seleccionados = []

    btn_guardar = QPushButton("Guardar Factura XML")
    btn_guardar.clicked.connect(self.guardar)
    layout.addWidget(btn_guardar)

  def agregar_item_factura(self):
    idx = self.combo_producto.currentIndex()
    if idx < 0 or idx >= len(self.prod_map):
      return
    prod = self.prod_map[idx]
    try:
      cant = int(self.inp_cantidad.text().strip())
      if cant <= 0:
        raise ValueError()
    except:
      QMessageBox.warning(self, "Aviso", "Cantidad inválida.")
      return

    try:
      precio = float(str(prod.get("precio", "0")).replace(",", ""))
    except:
      precio = 0.0

    subtotal = cant * precio
    self.items_seleccionados.append({
        "nombre": prod.get("nombre", ""),
        "cantidad": cant,
        "precio": precio,
        "subtotal": subtotal
    })

    r = self.tabla_items.rowCount()
    self.tabla_items.insertRow(r)
    self.tabla_items.setItem(r, 0, QTableWidgetItem(prod.get("nombre", "")))
    self.tabla_items.setItem(r, 1, QTableWidgetItem(str(cant)))
    self.tabla_items.setItem(r, 2, QTableWidgetItem(f"${precio:,.2f}"))
    self.tabla_items.setItem(r, 3, QTableWidgetItem(f"${subtotal:,.2f}"))

  def guardar(self):
    fac_id = self.inp_id.text().strip()
    cliente = self.combo_cliente.currentText().strip()
    if not fac_id or not cliente:
      QMessageBox.warning(self, "Aviso", "ID y cliente son obligatorios.")
      return
    if not self.items_seleccionados:
      QMessageBox.warning(self, "Aviso", "Debe agregar al menos un producto.")
      return

    total_val = sum(item["subtotal"] for item in self.items_seleccionados)
    total_str = f"{total_val:,.2f}"

    db = cargar_db_usuario(self.username)

    for f in db.get("facturas", []):
      if str(f.get("id")) == str(fac_id):
        QMessageBox.warning(
            self,
            "Error",
            f"Ya existe una factura con el ID '{fac_id}'.",
        )
        return

    filename = os.path.join(USER_DATA_DIR, f"factura_{fac_id}.xml")
    if os.path.exists(filename):
      QMessageBox.warning(
          self,
          "Error",
          f"Ya existe un archivo físico '{filename}' en la carpeta de datos del usuario.",
      )
      return

    fecha_actual = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    items_xml_str = ""
    for it in self.items_seleccionados:
      items_xml_str += f"    <Item>\n        <Nombre>{it['nombre']}</Nombre>\n        <Cantidad>{it['cantidad']}</Cantidad>\n        <PrecioUnitario>{it['precio']}</PrecioUnitario>\n        <Subtotal>{it['subtotal']}</Subtotal>\n    </Item>\n"

    contenido_xml = (
        f'<?xml version="1.0" encoding="UTF-8"?>\n'
        f"<Factura>\n"
        f"    <IdFactura>{fac_id}</IdFactura>\n"
        f"    <UsuarioSistema>{self.username}</UsuarioSistema>\n"
        f"    <Cliente>{cliente}</Cliente>\n"
        f"    <FechaEmision>{fecha_actual}</FechaEmision>\n"
        f"    <Items>\n{items_xml_str}    </Items>\n"
        f"    <Total monto='{total_str}'>${total_str}</Total>\n"
        f"</Factura>\n"
    )
    try:
      with open(filename, "w", encoding="utf-8") as f_out:
        f_out.write(contenido_xml)
    except Exception as e:
      QMessageBox.warning(
          self, "Error", f"No se pudo guardar el archivo XML físico: {e}"
      )
      return

    nueva = {
        "id": fac_id,
        "cliente": cliente,
        "fecha": datetime.datetime.now().strftime("%Y-%m-%d"),
        "total": f"${total_str}",
        "items": self.items_seleccionados
    }
    db["facturas"].append(nueva)
    guardar_db_usuario(self.username, db)
    QMessageBox.information(
        self,
        "Éxito",
        f"Factura guardada y archivo XML '{filename}' creado con éxito.",
    )
    self.accept()


class TablaArrastre(QTableWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self._arrastrando = False
        self._pos_arrastre = QPoint()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._arrastrando = True
            self._pos_arrastre = event.position().toPoint()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._arrastrando and (event.buttons() & Qt.MouseButton.LeftButton):
            pos_actual = event.position().toPoint()
            delta = pos_actual - self._pos_arrastre
            self.horizontalScrollBar().setValue(
                self.horizontalScrollBar().value() - delta.x()
            )
            self.verticalScrollBar().setValue(
                self.verticalScrollBar().value() - delta.y()
            )
            self._pos_arrastre = pos_actual
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._arrastrando = False
            self.unsetCursor()
        super().mouseReleaseEvent(event)


class EditarRegistroDialog(QDialog):
  def __init__(self, titulo, campos, editables=None, parent=None):
    super().__init__(parent)
    self.setWindowTitle(titulo)
    self.setMinimumSize(420, 260)
    self.setStyleSheet(STYLESHEET_CYBER_MEDICO)
    self.editables = set(editables or [])
    self.inputs = {}

    layout = QVBoxLayout(self)
    form = QFormLayout()

    for clave, valor in campos:
      inp = QLineEdit(str(valor))
      inp.setReadOnly(clave not in self.editables)
      self.inputs[clave] = inp
      form.addRow(QLabel(f"{clave}:"), inp)

    layout.addLayout(form)

    if self.editables:
      # Modo edición: hay campos modificables, se ofrece Guardar/Cancelar.
      botones = QDialogButtonBox(
        QDialogButtonBox.StandardButton.Save
        | QDialogButtonBox.StandardButton.Cancel
      )
      botones.accepted.connect(self.accept)
      botones.rejected.connect(self.reject)
      layout.addWidget(botones)
    else:
      # Modo solo visor: no hay nada que guardar, solo se permite cerrar.
      botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
      botones.rejected.connect(self.reject)
      botones.button(QDialogButtonBox.StandardButton.Close).clicked.connect(
        self.reject
      )
      layout.addWidget(botones)

  def valores(self):
    return {clave: inp.text() for clave, inp in self.inputs.items()}


class NexusApp(QMainWindow):

  def __init__(self, role="admin", username="admin"):
    super().__init__()
    self.role = role
    self.username = username
    self.setWindowTitle(
        f"NEXUS // ROL: {role.upper()} - USUARIO: {username}"
    )
    self.resize(1100, 650)
    self.setMinimumSize(850, 500)
    self.switch_to_login = False
    self.sidebar_visible = True
    self.init_ui()

  def init_ui(self):
    main_w = QWidget()
    main_w.setStyleSheet(STYLESHEET_CYBER_MEDICO)
    root_lay = QHBoxLayout(main_w)
    root_lay.setContentsMargins(0, 0, 0, 0)
    root_lay.setSpacing(0)

    self.sidebar = QFrame()
    self.sidebar.setObjectName("sidebar")
    self.sidebar.setFixedWidth(210)
    side_lay = QVBoxLayout(self.sidebar)
    side_lay.setContentsMargins(10, 15, 10, 15)
    side_lay.setSpacing(8)

    lbl_menu = QLabel("NEXUS MENÚ")
    lbl_menu.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    side_lay.addWidget(lbl_menu)

    side_lay.addSpacing(10)

    self.grupo_nav = QButtonGroup(self)
    self.grupo_nav.setExclusive(True)

    self.btn_cli_nav = QPushButton("Clientes")
    self.btn_cli_nav.setObjectName("navBtn")
    self.btn_cli_nav.setCheckable(True)
    self.btn_cli_nav.setChecked(True)
    self.btn_cli_nav.clicked.connect(lambda: self.stack.setCurrentIndex(0))
    self.grupo_nav.addButton(self.btn_cli_nav)
    side_lay.addWidget(self.btn_cli_nav)

    self.btn_inv_nav = QPushButton("Inventario")
    self.btn_inv_nav.setObjectName("navBtn")
    self.btn_inv_nav.setCheckable(True)
    self.btn_inv_nav.clicked.connect(lambda: self.stack.setCurrentIndex(1))
    self.grupo_nav.addButton(self.btn_inv_nav)
    side_lay.addWidget(self.btn_inv_nav)

    self.btn_fac_nav = QPushButton("Facturación")
    self.btn_fac_nav.setObjectName("navBtn")
    self.btn_fac_nav.setCheckable(True)
    self.btn_fac_nav.clicked.connect(lambda: self.stack.setCurrentIndex(2))
    self.grupo_nav.addButton(self.btn_fac_nav)
    side_lay.addWidget(self.btn_fac_nav)

    side_lay.addSpacing(5)

    btn_pass = QPushButton("Cambiar Clave")
    btn_pass.clicked.connect(self.abrir_cambiar_pass)
    side_lay.addWidget(btn_pass)

    if self.role == "admin":
      btn_ver_db = QPushButton("Ver Registros")
      btn_ver_db.clicked.connect(lambda: VerBDDexternaDialog(self).exec())
      side_lay.addWidget(btn_ver_db)

    side_lay.addStretch()

    btn_logout = QPushButton("Cerrar Sesión")
    btn_logout.clicked.connect(self.cerrar_sesion)
    side_lay.addWidget(btn_logout)

    root_lay.addWidget(self.sidebar)

    content_frame = QWidget()
    content_lay = QVBoxLayout(content_frame)
    content_lay.setContentsMargins(0, 0, 0, 0)
    content_lay.setSpacing(0)

    top_bar = QFrame()
    top_bar.setFixedHeight(40)
    top_bar.setStyleSheet(
        "background-color: #0f1021; border-bottom: 1px solid #1f2041;"
    )
    tb_lay = QHBoxLayout(top_bar)
    tb_lay.setContentsMargins(10, 0, 10, 0)

    self.btn_toggle = QPushButton("Menú")
    self.btn_toggle.setFixedWidth(70)
    self.btn_toggle.clicked.connect(self.toggle_sidebar)
    tb_lay.addWidget(self.btn_toggle)
    tb_lay.addSpacing(10)

    lbl_title_top = QLabel(
        f"NEXUS"
    )
    tb_lay.addWidget(lbl_title_top)
    content_lay.addWidget(top_bar)

    self.stack = QStackedWidget()
    self.stack.setStyleSheet(
        "QStackedWidget { background-color: #0b0c16; border: none; }"
    )
    self.stack.addWidget(self.crear_vista_clientes())
    self.stack.addWidget(self.crear_vista_inventario())
    self.stack.addWidget(self.crear_vista_facturacion())
    content_lay.addWidget(self.stack)

    footer = QFrame()
    footer.setFixedHeight(24)
    footer.setStyleSheet(
        "background-color: #0f1021; border-top: 1px solid #1f2041;"
    )
    f_lay = QHBoxLayout(footer)
    f_lay.setContentsMargins(10, 0, 10, 0)
    lbl_foot = QLabel("NEXUS // SISTEMA MULTI-USUARIO CONECTADO")
    lbl_foot.setStyleSheet("font-size: 9px; color: #8a99ad;")
    f_lay.addWidget(lbl_foot)
    content_lay.addWidget(footer)

    root_lay.addWidget(content_frame)
    self.setCentralWidget(main_w)

  def toggle_sidebar(self):
    self.sidebar_visible = not self.sidebar_visible
    self.sidebar.setVisible(self.sidebar_visible)

  def cerrar_sesion(self):
    self.switch_to_login = True
    self.close()

  def abrir_cambiar_pass(self):
    CambiarPasswordDialog(self.username, self).exec()

  def configurar_tabla(self, tabla, indice):
    header = tabla.horizontalHeader()
    header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    tabla.setWordWrap(True)
    tabla.setTextElideMode(Qt.TextElideMode.ElideNone)
    tabla.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    tabla.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    tabla.verticalHeader().setSectionResizeMode(
        QHeaderView.ResizeMode.ResizeToContents
    )
    if indice in [1, 3]:
      tabla.setStyleSheet(
          "QTableWidget { background-color: #0c0e1a; color: #e0f2fe;"
          " alternate-background-color: #11152d; gridline-color: #1f2041;"
          " border: 1px solid #1f2041; selection-background-color: #1a1b35;"
          " selection-color: #00f0ff; }"
      )
    else:
      tabla.setStyleSheet(
          "QTableWidget { background-color: #07080f; color: #e0f2fe;"
          " alternate-background-color: #0b0c16; gridline-color: #1f2041;"
          " border: 1px solid #1f2041; selection-background-color: #1a1b35;"
          " selection-color: #00f0ff; }"
      )
    tabla.setAlternatingRowColors(True)

  def crear_vista_clientes(self):
    w = QWidget()
    w.setStyleSheet("background-color: #0b0c16;")
    main_lay = QVBoxLayout(w)
    main_lay.setContentsMargins(8, 8, 8, 8)

    card = QFrame()
    card.setStyleSheet(
        "QFrame { background-color: #0b0c16; border: 1px solid #1f2041;"
        " border-radius: 6px; }"
    )
    lay = QVBoxLayout(card)
    lay.setContentsMargins(10, 10, 10, 10)
    lay.setSpacing(6)

    top_row = QHBoxLayout()
    lbl_sec = QLabel(f"GESTIÓN DE CLIENTES")
    lbl_sec.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    top_row.addWidget(lbl_sec)
    top_row.addStretch()

    self.search_cli = QLineEdit()
    self.search_cli.setPlaceholderText("Buscar por ID o Nombre...")
    self.search_cli.setFixedWidth(200)
    self.search_cli.textChanged.connect(self.poblar_tabla_clientes)
    top_row.addWidget(self.search_cli)

    btn_reg = QPushButton("Registrar Cliente")
    btn_reg.clicked.connect(self.abrir_modal_cliente)
    top_row.addWidget(btn_reg)
    lay.addLayout(top_row)

    self.t_cli = TablaArrastre()
    self.t_cli.cellDoubleClicked.connect(self.ver_cliente_doble_click)
    self.t_cli.setColumnCount(8)
    self.t_cli.setHorizontalHeaderLabels([
        "ID",
        "Nombre",
        "Email",
        "Teléfono",
        "Dirección",
        "Estado",
        "Fecha",
        "Acciones",
    ])
    self.configurar_tabla(self.t_cli, 1)
    self.poblar_tabla_clientes()
    lay.addWidget(self.t_cli)

    main_lay.addWidget(card)
    return w

  def abrir_modal_cliente(self):
    dlg = RegistrarClienteModal(self.username, None, self)
    if dlg.exec() == QDialog.DialogCode.Accepted:
      self.poblar_tabla_clientes()

  def ver_cliente_doble_click(self, row, column):
    item = self.t_cli.item(row, 0)
    if not item:
      return
    cliente_id = item.text()
    db = cargar_db_usuario(self.username)
    cliente = next(
      (c for c in db.get("clientes", []) if str(c.get("id")) == cliente_id),
      None
    )
    if not cliente:
      return

    campos = [
      ("ID", cliente.get("id", "")),
      ("Nombre", cliente.get("nombre", "")),
      ("Email", cliente.get("email", "")),
      ("Teléfono", cliente.get("telefono", "")),
      ("Dirección", cliente.get("direccion", "")),
      ("Estado", cliente.get("estado", "")),
      ("Fecha", cliente.get("fecha", "")),
    ]
    EditarRegistroDialog("Ver Cliente", campos, editables=[], parent=self).exec()

  def ver_editar_producto_doble_click(self, row, column):
    item = self.t_inv.item(row, 0)
    if not item:
      return
    prod_id = item.text()
    db = cargar_productos_global()
    producto = next(
      (p for p in db.get("inventario", []) if str(p.get("id")) == prod_id),
      None
    )
    if not producto:
      return

    campos = [
      ("ID", producto.get("id", "")),
      ("Nombre", producto.get("nombre", "")),
      ("Código", producto.get("codigo", "")),
      ("Descripción", producto.get("descripcion", "")),
      ("Precio", producto.get("precio", "")),
      ("Categoría", producto.get("categoria", "")),
      ("Estado", producto.get("estado", "")),
    ]

    EditarRegistroDialog("Ver Producto", campos, editables=[], parent=self).exec()

  def ver_factura_doble_click(self, row, column):
    item = self.t_fac.item(row, 0)
    if item:
      self.ver_factura_archivo(item.text())

  def modificar_cliente(self, cliente_id):
    db = cargar_db_usuario(self.username)
    cli_obj = None
    for c in db.get("clientes", []):
      if str(c.get("id")) == str(cliente_id):
        cli_obj = c
        break
    if cli_obj:
      dlg = RegistrarClienteModal(self.username, cli_obj, self)
      if dlg.exec() == QDialog.DialogCode.Accepted:
        self.poblar_tabla_clientes()

  def borrar_cliente(self, cliente_id):
    resp = QMessageBox.question(
        self,
        "Confirmar",
        "¿Está seguro de eliminar este cliente?",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
    )
    if resp == QMessageBox.StandardButton.Yes:
      db = cargar_db_usuario(self.username)
      db["clientes"] = [
          c for c in db.get("clientes", []) if str(c.get("id")) != str(cliente_id)
      ]
      guardar_db_usuario(self.username, db)
      self.poblar_tabla_clientes()

  def poblar_tabla_clientes(self):
    db = cargar_db_usuario(self.username)
    filtro = (
        self.search_cli.text().strip().lower()
        if hasattr(self, "search_cli")
        else ""
    )
    self.t_cli.setRowCount(0)
    for r, c in enumerate(db.get("clientes", [])):
      cid = str(c.get("id", ""))
      nombre = c.get("nombre", "")
      if filtro and (
          filtro not in cid.lower() and filtro not in nombre.lower()
      ):
        continue

      row = self.t_cli.rowCount()
      self.t_cli.insertRow(row)
      self.t_cli.setItem(row, 0, QTableWidgetItem(cid))
      self.t_cli.setItem(row, 1, QTableWidgetItem(nombre))
      self.t_cli.setItem(row, 2, QTableWidgetItem(c.get("email", "")))
      self.t_cli.setItem(row, 3, QTableWidgetItem(c.get("telefono", "")))
      self.t_cli.setItem(row, 4, QTableWidgetItem(c.get("direccion", "")))
      self.t_cli.setItem(row, 5, QTableWidgetItem(c.get("estado", "")))
      self.t_cli.setItem(row, 6, QTableWidgetItem(c.get("fecha", "")))

      btn_w = QWidget()
      blayout = QHBoxLayout(btn_w)
      blayout.setContentsMargins(1, 1, 1, 1)
      blayout.setSpacing(3)
      btn_mod = QPushButton("Modificar")
      btn_del = QPushButton("Borrar")
      btn_mod.clicked.connect(lambda _, x=cid: self.modificar_cliente(x))
      btn_del.clicked.connect(lambda _, x=cid: self.borrar_cliente(x))
      blayout.addWidget(btn_mod)
      blayout.addWidget(btn_del)
      self.t_cli.setCellWidget(row, 7, btn_w)

  def crear_vista_inventario(self):
    w = QWidget()
    w.setStyleSheet("background-color: #0b0c16;")
    main_lay = QVBoxLayout(w)
    main_lay.setContentsMargins(8, 8, 8, 8)

    card = QFrame()
    card.setStyleSheet(
        "QFrame { background-color: #0b0c16; border: 1px solid #1f2041;"
        " border-radius: 6px; }"
    )
    lay = QVBoxLayout(card)
    lay.setContentsMargins(10, 10, 10, 10)
    lay.setSpacing(6)

    top_row = QHBoxLayout()
    lbl_sec = QLabel("INVENTARIO GENERAL")
    lbl_sec.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    top_row.addWidget(lbl_sec)
    top_row.addStretch()

    self.search_inv = QLineEdit()
    self.search_inv.setPlaceholderText("Buscar por ID o Nombre...")
    self.search_inv.setFixedWidth(200)
    self.search_inv.textChanged.connect(self.poblar_tabla_inventario)
    top_row.addWidget(self.search_inv)

    btn_reg = QPushButton("Registrar Producto")
    btn_reg.clicked.connect(self.abrir_modal_producto)
    top_row.addWidget(btn_reg)
    lay.addLayout(top_row)

    self.t_inv = TablaArrastre()
    self.t_inv.cellDoubleClicked.connect(self.ver_editar_producto_doble_click)
    self.t_inv.setColumnCount(8)
    self.t_inv.setHorizontalHeaderLabels([
        "ID",
        "Nombre",
        "Código",
        "Descripción",
        "Precio",
        "Categoría",
        "Estado",
        "Acciones",
    ])
    self.configurar_tabla(self.t_inv, 2)
    self.poblar_tabla_inventario()
    lay.addWidget(self.t_inv)

    main_lay.addWidget(card)
    return w

  def abrir_modal_producto(self):
    dlg = RegistrarProductoModal(None, self)
    if dlg.exec() == QDialog.DialogCode.Accepted:
      self.poblar_tabla_inventario()

  def modificar_producto(self, prod_id):
    db = cargar_productos_global()
    p_obj = None
    for p in db.get("inventario", []):
      if str(p.get("id")) == str(prod_id):
        p_obj = p
        break
    if p_obj:
      dlg = RegistrarProductoModal(p_obj, self)
      if dlg.exec() == QDialog.DialogCode.Accepted:
        self.poblar_tabla_inventario()

  def borrar_producto(self, prod_id):
    resp = QMessageBox.question(
        self,
        "Confirmar",
        "¿Está seguro de eliminar este producto del inventario?",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
    )
    if resp == QMessageBox.StandardButton.Yes:
      db = cargar_productos_global()
      db["inventario"] = [
          p
          for p in db.get("inventario", [])
          if str(p.get("id")) != str(prod_id)
      ]
      guardar_productos_global(db)
      self.poblar_tabla_inventario()

  def poblar_tabla_inventario(self):
    db = cargar_productos_global()
    filtro = (
        self.search_inv.text().strip().lower()
        if hasattr(self, "search_inv")
        else ""
    )
    self.t_inv.setRowCount(0)
    for r, p in enumerate(db.get("inventario", [])):
      pid = str(p.get("id", ""))
      nombre = p.get("nombre", "")
      if filtro and (
          filtro not in pid.lower() and filtro not in nombre.lower()
      ):
        continue

      row = self.t_inv.rowCount()
      self.t_inv.insertRow(row)
      self.t_inv.setItem(row, 0, QTableWidgetItem(pid))
      self.t_inv.setItem(row, 1, QTableWidgetItem(nombre))
      self.t_inv.setItem(row, 2, QTableWidgetItem(p.get("codigo", "")))
      self.t_inv.setItem(row, 3, QTableWidgetItem(p.get("descripcion", "")))
      self.t_inv.setItem(row, 4, QTableWidgetItem(f"${p.get('precio', '')}"))
      self.t_inv.setItem(row, 5, QTableWidgetItem(p.get("categoria", "")))
      self.t_inv.setItem(row, 6, QTableWidgetItem(p.get("estado", "")))

      btn_w = QWidget()
      blayout = QHBoxLayout(btn_w)
      blayout.setContentsMargins(1, 1, 1, 1)
      blayout.setSpacing(3)
      btn_mod = QPushButton("Modificar")
      btn_del = QPushButton("Borrar")
      btn_mod.clicked.connect(lambda _, x=pid: self.modificar_producto(x))
      btn_del.clicked.connect(lambda _, x=pid: self.borrar_producto(x))
      blayout.addWidget(btn_mod)
      blayout.addWidget(btn_del)
      self.t_inv.setCellWidget(row, 7, btn_w)

  def crear_vista_facturacion(self):
    w = QWidget()
    w.setStyleSheet("background-color: #0b0c16;")
    main_lay = QVBoxLayout(w)
    main_lay.setContentsMargins(8, 8, 8, 8)

    card = QFrame()
    card.setStyleSheet(
        "QFrame { background-color: #0b0c16; border: 1px solid #1f2041;"
        " border-radius: 6px; }"
    )
    lay = QVBoxLayout(card)
    lay.setContentsMargins(10, 10, 10, 10)
    lay.setSpacing(6)

    top_row = QHBoxLayout()
    lbl_sec = QLabel(f"FACTURACIÓN")
    lbl_sec.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    top_row.addWidget(lbl_sec)
    top_row.addStretch()

    self.search_fac = QLineEdit()
    self.search_fac.setPlaceholderText("Buscar por ID o Cliente...")
    self.search_fac.setFixedWidth(200)
    self.search_fac.textChanged.connect(self.poblar_tabla_facturacion)
    top_row.addWidget(self.search_fac)

    btn_fac = QPushButton("Generar Factura XML")
    btn_fac.clicked.connect(self.abrir_modal_factura)
    top_row.addWidget(btn_fac)
    lay.addLayout(top_row)

    self.t_fac = TablaArrastre()
    self.t_fac.cellDoubleClicked.connect(self.ver_factura_doble_click)
    self.t_fac.setColumnCount(5)
    self.t_fac.setHorizontalHeaderLabels(
        ["ID Factura", "Cliente", "Fecha", "Total", "Acciones"]
    )
    self.configurar_tabla(self.t_fac, 3)
    self.poblar_tabla_facturacion()
    lay.addWidget(self.t_fac)

    main_lay.addWidget(card)
    return w

  def abrir_modal_factura(self):
    dlg = GenerarFacturaModal(self.username, self)
    if dlg.exec() == QDialog.DialogCode.Accepted:
      self.poblar_tabla_facturacion()
      db = cargar_db_usuario(self.username)
      facturas = db.get("facturas", [])
      if facturas:
        self.ver_factura_archivo(str(facturas[-1].get("id", "")))

  def ver_factura_archivo(self, fac_id):
    VerFacturaTxtDialog(fac_id, self.username, self).exec()

  def borrar_factura(self, fac_id):
    resp = QMessageBox.question(
        self,
        "Confirmar",
        "¿Está seguro de eliminar esta factura?",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
    )
    if resp == QMessageBox.StandardButton.Yes:
      db = cargar_db_usuario(self.username)
      db["facturas"] = [
          f for f in db.get("facturas", []) if str(f.get("id")) != str(fac_id)
      ]
      guardar_db_usuario(self.username, db)
      filename = os.path.join(USER_DATA_DIR, f"factura_{fac_id}.xml")
      if os.path.exists(filename):
        try:
          os.remove(filename)
        except:
          pass
      self.poblar_tabla_facturacion()

  def poblar_tabla_facturacion(self):
    db = cargar_db_usuario(self.username)
    filtro = (
        self.search_fac.text().strip().lower()
        if hasattr(self, "search_fac")
        else ""
    )
    self.t_fac.setRowCount(0)
    for r, f in enumerate(db.get("facturas", [])):
      fid = str(f.get("id", ""))
      cliente = f.get("cliente", "")
      if filtro and (
          filtro not in fid.lower() and filtro not in cliente.lower()
      ):
        continue

      row = self.t_fac.rowCount()
      self.t_fac.insertRow(row)
      self.t_fac.setItem(row, 0, QTableWidgetItem(fid))
      self.t_fac.setItem(row, 1, QTableWidgetItem(cliente))
      self.t_fac.setItem(row, 2, QTableWidgetItem(f.get("fecha", "")))
      self.t_fac.setItem(row, 3, QTableWidgetItem(f.get("total", "")))

      btn_w = QWidget()
      blayout = QHBoxLayout(btn_w)
      blayout.setContentsMargins(1, 1, 1, 1)
      blayout.setSpacing(3)
      btn_ver = QPushButton("Ver Factura")
      btn_del = QPushButton("Borrar")
      btn_ver.clicked.connect(lambda _, x=fid: self.ver_factura_archivo(x))
      btn_del.clicked.connect(lambda _, x=fid: self.borrar_factura(x))
      blayout.addWidget(btn_ver)
      blayout.addWidget(btn_del)
      self.t_fac.setCellWidget(row, 4, btn_w)


if __name__ == "__main__":
  if sys.platform.startswith("win"):
    # Para que Windows muestre el icono propio en la barra de tareas
    try:
      import ctypes
      ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("NexusSoftware.NexusFacturacion")
    except Exception:
      pass
  app = QApplication(sys.argv)
  app.setApplicationName(APP_NAME)
  app.setApplicationDisplayName(APP_NAME)
  app.setDesktopFileName(APP_DESKTOP_ID)
  if os.path.exists(APP_ICON_PATH):
    app.setWindowIcon(QIcon(APP_ICON_PATH))

  while True:
    role_dlg = InitialRoleDialog()
    if role_dlg.exec() == QDialog.DialogCode.Accepted and role_dlg.role_selected:
      rol = role_dlg.role_selected
      login_dlg = LoginDialog(rol)
      if (
          login_dlg.exec() == QDialog.DialogCode.Accepted
          and login_dlg.authenticated
      ):
        main_window = NexusApp(
            role=login_dlg.current_user_role, username=login_dlg.current_user_name
        )
        if os.path.exists(APP_ICON_PATH):
          main_window.setWindowIcon(QIcon(APP_ICON_PATH))
        main_window.show()
        app.exec()
        if main_window.switch_to_login:
          continue
        else:
          break
      else:
        continue
    else:
      break
  sys.exit(0)
